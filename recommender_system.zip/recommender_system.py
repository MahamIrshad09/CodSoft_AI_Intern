import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# Load the ratings and movies datasets
ratings = pd.read_csv('ratings.csv')
movies = pd.read_csv('movies.csv')

# Merge the ratings and movies data
movie_data = pd.merge(ratings, movies, on='movieId')

# Create a user-movie rating matrix
user_movie_ratings = movie_data.pivot_table(index='userId', columns='title', values='rating')

# Fill missing values with 0 (assuming no rating means a rating of 0)
user_movie_ratings = user_movie_ratings.fillna(0)

# Calculate the cosine similarity between movies
movie_similarity = cosine_similarity(user_movie_ratings.T)  # Transpose the matrix

# Create a DataFrame with movie similarities
movie_similarity_df = pd.DataFrame(movie_similarity, index=user_movie_ratings.columns, columns=user_movie_ratings.columns)

# Define a function to get movie recommendations for a user
def get_movie_recommendations(movie_title, user_rating):
    similar_scores = movie_similarity_df[movie_title] * user_rating
    similar_scores = similar_scores.sort_values(ascending=False)
    return similar_scores

# Sample user ratings
user_ratings = [
    ("Toy Story (1995)", 4),
    ("Jumanji (1995)", 3),
    ("Jurassic Park (1993)", 5)
]

recommendations = pd.DataFrame()

for movie, rating in user_ratings:
    recommendations = pd.concat([recommendations, get_movie_recommendations(movie, rating)], axis=1)

# Sum up the scores and recommend top movies
recommendations = recommendations.sum(axis=1).sort_values(ascending=False)

recommended_movies = recommendations.index.tolist()
for movie in recommended_movies[:10]:
    print(movie)


